
var data = [
	{
		home: 'kek'
	},
	//page 1
	{
		question: 'Which belongs in an earthquake emergency supplies package?',
		displayName: 'PageOneContent',
		answer1: 'Meat loaf',
		answer2: 'Watermelon',
		answer3: 'Trail mix',
		answer4: 'Pineapple'
	},
	//page 2
	{
		question: 'What is the correct way to behave during an earthquake?',
		displayName: 'PageTwoContent',
		answer1: 'Panic and run',
		answer2: 'Go on Facebook',
		answer3: 'Keep calm',
		answer4: 'Dance'
	}
];

var pageVisitedBool= [
	//no page
	true,
	//page1
	false,
	//2
	false,
	//3
	false,
	//4
	false,
	//5
	false

];

var pageHash = [
	'#home',
	'#one',
	'#two',
	'#three',
	'#four',
	'#five'
]

