//>>excludeStart("jqmBuildExclude", pragmas.jqmBuildExclude);
//>>group: exclude

define([
	"./jquery.mobile.defaults",
	"./jquery.mobile.data",
	"./jquery.mobile.helpers"
], function() {});
//>>excludeEnd("jqmBuildExclude");
