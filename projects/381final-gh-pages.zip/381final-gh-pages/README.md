# 381final
381 final project

Custom UX
- Hands free ux
- UX is all done through device orientation


Technical Parts
- Geolocaiton
  - Location
  - Altitude
- Google maps API
  - Location
  - Plotting
- Device Orientation
  - Plotting
  - Angles
- Device Acceleration
  - Speed
- PHP/MySQL/Apache
  - Ajax/XML
  - Saves Hills with markers
- React (Framework)
  - Manages high amounts of data
- HTML Canvas
  - Drawing
