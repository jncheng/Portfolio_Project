# IAT381_assignment2

This is an alarm web app that tests your basic arithmetic skills.

Drag the spinning number balls into the dotted boxes to set the alarm time (24-hour time).

When the alarm is ringing, a math problem will show up in the central ball. Drag the right answer into the dotted box to turn it off.

<a href="http://ai4281.github.io/IAT381_assignment2/">Try It Out!</a>
